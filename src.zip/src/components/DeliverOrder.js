import React, { useState } from 'react';
import Web3 from 'web3';
import SupplierPerformanceContract from '../utils/SupplierPerformanceService';

const DeliverOrder = () => {
  const [orderId, setOrderId] = useState(0);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const web3 = new Web3(window.ethereum);
    const networkId = await web3.eth.net.getId();
    const deployedNetwork = SupplierPerformanceContract.networks[networkId];
    const instance = new web3.eth.Contract(
      SupplierPerformanceContract.abi,
      deployedNetwork && deployedNetwork.address,
    );

    const accounts = await web3.eth.getAccounts();
    await instance.methods.deliverOrder(orderId).send({ from: accounts[0] });

    setOrderId(0);
  };

  return (
    <div>
      <h2>Deliver Order</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Order ID:</label>
          <input
            type="number"
            value={orderId}
            onChange={(e) => setOrderId(parseInt(e.target.value))}
          />
        </div>
        <button type="submit">Deliver Order</button>
      </form>
    </div>
  );
};

export default DeliverOrder;