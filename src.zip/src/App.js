import React, { Component } from 'react';
import Web3 from 'web3';
import './App.css';
import SupplierPerformance from './utils/SupplierPerformanceService';
import SupplierPerformanceABI from './utils/SupplierPerformanceABI.json';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      account: '',
      contract: null,
      suppliers: [],
      orders: [],
      bonusPool: 0,
      newOrderTotalProducts: 0,
      deliverOrderId: 0,
      acceptOrderId: 0,
      acceptOrderProducts: 0,
      evaluateSupplierAddress: '',
      admin: '',
    };

    this.handleInputChange = this.handleInputChange.bind(this);
    this.handleCreateOrder = this.handleCreateOrder.bind(this);
    this.handleDeliverOrder = this.handleDeliverOrder.bind(this);
    this.handleAcceptOrder = this.handleAcceptOrder.bind(this);
    this.handleEvaluateSupplier = this.handleEvaluateSupplier.bind(this);
    this.handleAddBonus = this.handleAddBonus.bind(this);
  }

  async componentDidMount() {
    try {
      // Request account access
      await window.ethereum.request({ method: 'eth_requestAccounts' });
      await this.loadBlockchainData();
    } catch (error) {
      // User denied account access
      console.error(error);
    }
  }

  async loadBlockchainData() {
    const web3 = new Web3(window.ethereum);
    const accounts = await web3.eth.getAccounts();
    this.setState({ account: accounts[0] });

    const networkId = await web3.eth.net.getId();
    console.log('Network ID:', networkId);
    
    const networkData = SupplierPerformance.networks[networkId.toString()];
    console.log('Network Data:', networkData);

    if (networkData) {
      const contract = new web3.eth.Contract(SupplierPerformanceABI, networkData.address);
      this.setState({ contract });

      const bonusPool = await contract.methods.bonusPool().call();
      this.setState({ bonusPool: web3.utils.fromWei(bonusPool, 'ether') });

      const admin = await contract.methods.admin().call();
      this.setState({ admin });

      const suppliers = [];
      const orders = [];

      // 获取供应商数据
      const supplierData = await contract.methods.getSupplierData(this.state.account).call();
      suppliers.push({
        addr: this.state.account,
        totalOrders: supplierData.totalOrders,
        onTimeOrders: supplierData.onTimeOrders,
        totalProducts: supplierData.totalProducts,
        acceptedProducts: supplierData.acceptedProducts,
        score: await contract.methods.getSupplierScore(this.state.account).call(),
        ranking: await contract.methods.getSupplierRanking(this.state.account).call(),
      });

      // 获取供应商订单
      const supplierOrders = await contract.methods.getSupplierOrders(this.state.account).call();
      supplierOrders.forEach((order) => {
        orders.push({
          id: order.orderId,
          createdTime: order.createdTime,
          deliveredTime: order.deliveredTime,
          acceptedProducts: order.acceptedProducts,
          isDelivered: order.isDelivered,
          isAccepted: order.isAccepted,
        });
      });

      this.setState({ suppliers, orders });
    } else {
      window.alert('SupplierPerformance contract not deployed to detected network.');
    }
  }

  handleInputChange(event) {
    const target = event.target;
    const value = target.type === 'checkbox' ? target.checked : target.value;
    const name = target.name;

    this.setState({
      [name]: value,
    });
  }

  async handleCreateOrder(event) {
    event.preventDefault();
    const { contract, account, newOrderTotalProducts } = this.state;
    if (contract) {
      await contract.methods.createOrder(newOrderTotalProducts).send({ from: account });
      this.setState({ newOrderTotalProducts: 0 });
      await this.loadBlockchainData();
    }
  }

  async handleDeliverOrder(event) {
    event.preventDefault();
    const { contract, account, deliverOrderId } = this.state;
    if (contract) {
      try {
        await contract.methods.deliverOrder(deliverOrderId).send({ from: account });
        this.setState({ deliverOrderId: 0 });
        await this.loadBlockchainData();
      } catch (error) {
        console.error('Error delivering order:', error);
        // 处理错误的逻辑
      }
    } else {
      console.error('Contract is not initialized');
      // 处理合约未初始化的逻辑
    }
  }

  async handleAcceptOrder(event) {
    event.preventDefault();
    const { contract, account, acceptOrderId, acceptOrderProducts } = this.state;
    if (contract) {
      try {
        await contract.methods.updateSupplierData(acceptOrderId, acceptOrderProducts).send({ from: account });
        this.setState({ acceptOrderId: 0, acceptOrderProducts: 0 });
        await this.loadBlockchainData();
      } catch (error) {
        console.error('Error accepting order:', error);
        // 处理错误的逻辑
      }
    } else {
      console.error('Contract is not initialized');
      // 处理合约未初始化的逻辑
    }
  }

  async handleEvaluateSupplier(event) {
    event.preventDefault();
    const { contract, account, evaluateSupplierAddress } = this.state;
    if (contract) {
      try {
        await contract.methods.evaluateSupplierPerformance(evaluateSupplierAddress).send({ from: account });
        this.setState({ evaluateSupplierAddress: '' });
        await this.loadBlockchainData();
      } catch (error) {
        console.error('Error evaluating supplier:', error);
        // 处理错误的逻辑
      }
    } else {
      console.error('Contract is not initialized');
      // 处理合约未初始化的逻辑
    }
  }

  async handleAddBonus(event) {
    event.preventDefault();
    const { contract, account } = this.state;
    if (contract) {
      try {
        const web3 = new Web3(window.ethereum);
        const bonusAmount = web3.utils.toWei('1', 'ether');
        await contract.methods.addBonusToPool().send({ from: account, value: bonusAmount });
        await this.loadBlockchainData();
      } catch (error) {
        console.error('Error adding bonus:', error);
        // 处理错误的逻辑
      }
    } else {
      console.error('Contract is not initialized');
      // 处理合约未初始化的逻辑
    }
  }

  render() {
    const {
      account,
      suppliers,
      orders,
      bonusPool,
      newOrderTotalProducts,
      deliverOrderId,
      acceptOrderId,
      acceptOrderProducts,
      evaluateSupplierAddress,
      admin,
    } = this.state;
  
    return (
      <div className="app">
        <header className="app-header">
          <h1>Supplier Performance Management</h1>
          <p>Current Account: {account}</p>
        </header>
        <main className="app-content">
          <div className="row">
            <section className="bonus-pool col-md-6">
              <h2>Bonus Pool</h2>
              <p>{bonusPool} ETH</p>
            </section>
            {account === admin && (
              <section className="admin-actions col-md-6">
                <h2>Admin Actions</h2>
                <form onSubmit={this.handleAddBonus}>
                  <button type="submit" className="btn btn-primary">Add Bonus to Pool</button>
                </form>
              </section>
            )}
          </div>
          <section className="supplier-list">
            <h2>Suppliers</h2>
            <table className="table table-striped">
              <thead>
                <tr>
                  <th>Address</th>
                  <th>Total Orders</th>
                  <th>On-Time Orders</th>
                  <th>Total Products</th>
                  <th>Accepted Products</th>
                  <th>Score</th>
                  <th>Ranking</th>
                </tr>
              </thead>
              <tbody>
                {suppliers.map((supplier) => (
                  <tr key={supplier.addr}>
                    <td>{supplier.addr}</td>
                    <td>{supplier.totalOrders.toString()}</td>
                    <td>{supplier.onTimeOrders.toString()}</td>
                    <td>{supplier.totalProducts.toString()}</td>
                    <td>{supplier.acceptedProducts.toString()}</td>
                    <td>{supplier.score.toString()}</td>
                    <td>{supplier.ranking.toString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>
          <section className="order-list">
            <h2>Orders</h2>
            <table className="table table-striped">
              <thead>
                <tr>
                  <th>Order ID</th>
                  <th>Created Time</th>
                  <th>Delivered Time</th>
                  <th>Accepted Products</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order) => (
                  <tr key={order.id}>
                    <td>{order.id.toString()}</td>
                    <td>{new Date(parseInt(order.createdTime) * 1000).toLocaleString()}</td>
                    <td>
                      {parseInt(order.deliveredTime) > 0
                        ? new Date(parseInt(order.deliveredTime) * 1000).toLocaleString()
                        : '-'}
                    </td>
                    <td>{order.acceptedProducts.toString()}</td>
                    <td>
                      {order.isAccepted
                        ? 'Accepted'
                        : order.isDelivered
                        ? 'Delivered'
                        : 'Created'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>
          <div className="row">
            <section className="create-order col-md-6">
              <h2>Create Order</h2>
              <div className="form-group">
                <input
                  type="number"
                  name="newOrderTotalProducts"
                  value={newOrderTotalProducts}
                  onChange={this.handleInputChange}
                  placeholder="Total Products"
                  className="form-control"
                />
              </div>
              <button onClick={this.handleCreateOrder} className="btn btn-primary">Create Order</button>
            </section>
            <section className="deliver-order col-md-6">
              <h2>Deliver Order</h2>
              <div className="form-group">
                <input
                  type="number"
                  name="deliverOrderId"
                  value={deliverOrderId}
                  onChange={this.handleInputChange}
                  placeholder="Order ID"
                  className="form-control"
                />
              </div>
              <button onClick={this.handleDeliverOrder} className="btn btn-primary">Deliver Order</button>
            </section>
          </div>
          <div className="row">
            <section className="accept-order col-md-6">
              <h2>Accept Order</h2>
              <div className="form-group">
                <input
                  type="number"
                  name="acceptOrderId"
                  value={acceptOrderId}
                  onChange={this.handleInputChange}
                  placeholder="Order ID"
                  className="form-control"
                />
              </div>
              <div className="form-group">
                <input
                  type="number"
                  name="acceptOrderProducts"
                  value={acceptOrderProducts}
                  onChange={this.handleInputChange}
                  placeholder="Accepted Products"
                  className="form-control"
                />
              </div>
              <button onClick={this.handleAcceptOrder} className="btn btn-primary">Accept Order</button>
            </section>
            <section className="evaluate-supplier col-md-6">
              <h2>Evaluate Supplier</h2>
              <div className="form-group">
                <input
                  type="text"
                  name="evaluateSupplierAddress"
                  value={evaluateSupplierAddress}
                  onChange={this.handleInputChange}
                  placeholder="Supplier Address"
                  className="form-control"
                />
              </div>
              <button onClick={this.handleEvaluateSupplier} className="btn btn-primary">Evaluate Supplier</button>
            </section>
          </div>
        </main>
        <footer className="app-footer">
          <div className="row">
            <div className="col-md-12 text-right">
              <p>&copy;                     2024EEMT6000H Supplier Performance Management. All rights reserved.</p>
            </div>
          </div>
        </footer>
      </div>
    );
  }
}

export default App;