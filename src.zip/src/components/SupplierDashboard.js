import React, { useState, useEffect } from 'react';
import SupplierPerformanceService from '../utils/SupplierPerformanceService';

const SupplierDashboard = () => {
  const [supplierData, setSupplierData] = useState(null);
  const [onTimeRate, setOnTimeRate] = useState(null);
  const [acceptedRate, setAcceptedRate] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const accounts = await window.ethereum.request({ method: 'eth_accounts' });
        const supplierAddress = accounts[0];

        const data = await SupplierPerformanceService.getSupplierData(supplierAddress);
        setSupplierData(data);

        const onTimeRate = await SupplierPerformanceService.getOnTimeDeliveryRate(supplierAddress);
        setOnTimeRate(onTimeRate);

        const acceptedRate = await SupplierPerformanceService.getAcceptedProductRate(supplierAddress);
        setAcceptedRate(acceptedRate);
      } catch (error) {
        console.error('Error fetching supplier data:', error);
        // 处理错误,例如显示错误消息给用户
      }
    };

    fetchData();
  }, []);

  if (!supplierData) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <h2>Supplier Dashboard</h2>
      <p>Total Orders: {supplierData[0]}</p>
      <p>On-Time Orders: {supplierData[1]}</p>
      <p>Total Products: {supplierData[2]}</p>
      <p>Accepted Products: {supplierData[3]}</p>
      <p>On-Time Delivery Rate: {onTimeRate}%</p>
      <p>Accepted Product Rate: {acceptedRate}%</p>
      {/* 添加创建订单和交付订单的按钮或链接 */}
    </div>
  );
};

export default SupplierDashboard;