import React, { useState } from 'react';
import Web3 from 'web3';
import SupplierPerformanceContract from '../utils/SupplierPerformanceService';

const AdminDashboard = () => {
  const [orderId, setOrderId] = useState(0);
  const [acceptedProducts, setAcceptedProducts] = useState(0);
  const [supplierAddress, setSupplierAddress] = useState('');

  const handleUpdateSupplierData = async (e) => {
    e.preventDefault();

    const web3 = new Web3(window.ethereum);
    const networkId = await web3.eth.net.getId();
    const deployedNetwork = SupplierPerformanceContract.networks[networkId];
    const instance = new web3.eth.Contract(
      SupplierPerformanceContract.abi,
      deployedNetwork && deployedNetwork.address,
    );

    const accounts = await web3.eth.getAccounts();
    await instance.methods.updateSupplierData(orderId, acceptedProducts).send({ from: accounts[0] });

    setOrderId(0);
    setAcceptedProducts(0);
  };

  const handleEvaluateSupplier = async (e) => {
    e.preventDefault();

    const web3 = new Web3(window.ethereum);
    const networkId = await web3.eth.net.getId();
    const deployedNetwork = SupplierPerformanceContract.networks[networkId];
    const instance = new web3.eth.Contract(
      SupplierPerformanceContract.abi,
      deployedNetwork && deployedNetwork.address,
    );

    const accounts = await web3.eth.getAccounts();
    await instance.methods.evaluateSupplierPerformance(supplierAddress).send({ from: accounts[0] });

    setSupplierAddress('');
  };

  return (
    <div>
      <h2>Admin Dashboard</h2>
      <form onSubmit={handleUpdateSupplierData}>
        <div>
          <label>Order ID:</label>
          <input
            type="number"
            value={orderId}
            onChange={(e) => setOrderId(parseInt(e.target.value))}
          />
        </div>
        <div>
          <label>Accepted Products:</label>
          <input
            type="number"
            value={acceptedProducts}
            onChange={(e) => setAcceptedProducts(parseInt(e.target.value))}
          />
        </div>
        <button type="submit">Update Supplier Data</button>
      </form>
      <form onSubmit={handleEvaluateSupplier}>
        <div>
          <label>Supplier Address:</label>
          <input
            type="text"
            value={supplierAddress}
            onChange={(e) => setSupplierAddress(e.target.value)}
          />
        </div>
        <button type="submit">Evaluate Supplier</button>
      </form>
    </div>
  );
};

export default AdminDashboard;