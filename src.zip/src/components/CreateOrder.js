import React, { useState } from 'react';
import Web3 from 'web3';
import SupplierPerformanceContract from '../utils/SupplierPerformanceService';

const CreateOrder = () => {
  const [totalProducts, setTotalProducts] = useState(0);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const web3 = new Web3(window.ethereum);
    const networkId = await web3.eth.net.getId();
    const deployedNetwork = SupplierPerformanceContract.networks[networkId];
  
    if (!deployedNetwork) {
      alert('SupplierPerformance contract not deployed to detected network.');
      return;
    }
  
    const instance = new web3.eth.Contract(
      SupplierPerformanceContract.abi,
      deployedNetwork.address,
    );
  
    console.log('Deployed Network:', deployedNetwork);
    console.log('Contract Instance:', instance);
  
    const accounts = await web3.eth.getAccounts();
    await instance.methods.createOrder(totalProducts).send({ from: accounts[0] });
  
    setTotalProducts(0);
  };

  return (
    <div>
      <h2>Create Order</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Total Products:</label>
          <input
            type="number"
            value={totalProducts}
            onChange={(e) => setTotalProducts(parseInt(e.target.value))}
          />
        </div>
        <button type="submit">Create Order</button>
      </form>
    </div>
  );
};

export default CreateOrder;