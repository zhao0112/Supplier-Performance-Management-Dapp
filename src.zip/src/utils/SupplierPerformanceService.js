import Web3 from 'web3';
import SupplierPerformanceABI from './SupplierPerformanceABI.json';

let web3;

if (window.ethereum) {
  web3 = new Web3(window.ethereum);
} else if (window.web3) {
  web3 = new Web3(window.web3.currentProvider);
} else {
  const provider = new Web3.providers.HttpProvider('https://ropsten.infura.io/v3/YOUR_INFURA_PROJECT_ID');
  web3 = new Web3(provider);
}

const contractAddress = '0x2721094F42E0dD988d6E373B23824fd800cb4736'; // 替换为你部署的合约地址

console.log('SupplierPerformanceABI:', SupplierPerformanceABI);

const SupplierPerformanceService = {
  contract: new web3.eth.Contract(SupplierPerformanceABI, contractAddress),
  
  networks: {
    '23412': {
      address: '0x2721094F42E0dD988d6E373B23824fd800cb4736',
    },
    // 添加其他网络的合约地址
  },

  async createOrder(totalProducts) {
    const accounts = await web3.eth.getAccounts();
    return this.contract.methods.createOrder(totalProducts).send({ from: accounts[0] });
  },

  async deliverOrder(orderId) {
    const accounts = await web3.eth.getAccounts();
    return this.contract.methods.deliverOrder(orderId).send({ from: accounts[0] });
  },

  async getSupplierData(supplierAddress) {
    return this.contract.methods.getSupplierData(supplierAddress).call();
  },

  async getOnTimeDeliveryRate(supplierAddress) {
    return this.contract.methods.getOnTimeDeliveryRate(supplierAddress).call();
  },

  async getAcceptedProductRate(supplierAddress) {
    return this.contract.methods.getAcceptedProductRate(supplierAddress).call();
  },

  // 添加其他与智能合约交互的方法
};

export default SupplierPerformanceService;